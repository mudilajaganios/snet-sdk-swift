//
//  snet_swift_pkg_macOS.h
//  snet-swift-pkg-macOS
//
//  Created by Jagan Kumar Mudila on 30/03/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for snet_swift_pkg_macOS.
FOUNDATION_EXPORT double snet_swift_pkg_macOSVersionNumber;

//! Project version string for snet_swift_pkg_macOS.
FOUNDATION_EXPORT const unsigned char snet_swift_pkg_macOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <snet_swift_pkg_macOS/PublicHeader.h>


